CREATE DATABASE RaceDayActivitiesDB;

